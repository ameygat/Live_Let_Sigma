echo OFF
echo Attack 01 ...
REG DELETE "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "Automatic Calculator" /f
REG ADD "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "Automatic Calculator" /t REG_SZ /F /D C:\attack\acalc.exe
REG Query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
echo Done!