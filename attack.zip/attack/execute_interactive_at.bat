echo OFF
echo "Executing at command..."
echo at 13:20 /interactive cmd
at 13:20 /interactive cmd
echo "Done!"