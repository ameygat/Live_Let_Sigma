import sys
from sigma.collection import SigmaCollection
from sigma.validators.core import validators as core_validators
from sigma.validation import SigmaValidator
from sigma.exceptions import SigmaError


# 1. Optionally import the SigmaHQ specific validators for more strict checks
try:
    from sigma.validators.sigmahq import validators as sigmahq_validators
    # Merge core and SigmaHQ validators
    all_validators = {**core_validators, **sigmahq_validators}
except ImportError:
    print("[!] SigmaHQ validators not found. Using core validators only.")
    all_validators = core_validators
"""
all_validators = core_validators
"""

def validate_sigma_rule(rule_path):
    # Initialize the validator with all discovered validator classes
    validator = SigmaValidator(all_validators.values())

    try:
        # Load the rule(s) from a file
        with open(rule_path, 'r', encoding='utf-8') as f:
            rule_content = f.read()
        
        # Parse the Sigma rule
        # SigmaCollection handles files with one or multiple rules
        rule_collection = SigmaCollection.from_yaml(rule_content)
        
        # Run validation
        issues = validator.validate_rules(rule_collection)
        
        if not issues:
            print(f"» Rule '{rule_path}' is valid!")
            return

        errors = [
            i for i in issues 
            if i.severity.value > 2 #2 is MEDIUM
        ]
        
        print(f"× Found {len(errors)} High Severity errors(s) in '{rule_path}':\n")        
        # Format and display the error list
        for issue in errors:
            # issue object contains: message, severity, rule, and validator class
            severity = issue.__class__.__name__
            print(f"[{severity}] {str(issue)}")
            if hasattr(issue, 'description') and issue.description:
                print(f"    Details: {issue.description}")
            print("-" * 40)


        input1= "n" #input("Do you want to show Medium or Less Severity Warnings ?(Y/N): ")
        if input1.lower() == "y":
            for issue in issues:
                # issue object contains: message, severity, rule, and validator class
                severity = issue.__class__.__name__
                print(f"[{severity}] {str(issue)}")
                if hasattr(issue, 'description') and issue.description:
                    print(f"    Details: {issue.description}")
                print("-" * 40)                


    except SigmaError as e:
        print(f"Critial Parsing Error: The YAML structure itself is invalid.")
        print(f"Error: {e}")
    except FileNotFoundError:
        print(f"Error: File '{rule_path}' not found.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python validate_sigma.py <path_to_rule.yml>")
    else:
        validate_sigma_rule(sys.argv[1])