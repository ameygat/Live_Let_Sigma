# List all services that are currently running
Write-Host "--- Running Services ---"

# Get services, filter for running status, and format as a table
Get-Service |
    Where-Object { $_.Status -eq 'Running' } |
    Format-Table -Property Name, DisplayName, Status -AutoSize